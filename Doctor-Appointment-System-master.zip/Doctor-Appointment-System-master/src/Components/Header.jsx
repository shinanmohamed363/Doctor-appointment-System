import React from 'react'
import { ReactDOM } from 'react'


function Header() {
  return (
    <div>
        <header>
            <nav className='navbar text-center navbar-dark bg-dark '>
                <div>
                    <a href='/' className='navbar-brand'>Hospital Management System</a>
                </div>
            </nav>
    </header>

    </div>
    
        
    
  )
}

export default Header