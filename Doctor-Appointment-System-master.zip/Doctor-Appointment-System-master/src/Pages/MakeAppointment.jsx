import React from 'react'
import BookAppointment from '../Components/BookAppointment'
import Footer from '../Components/Footer'
import Header from '../Components/Header'

function MakeAppointment() {
  return (
    <div>
        <Header/>
        <BookAppointment/>
        <Footer/>
    </div>
    
  )
}

export default MakeAppointment