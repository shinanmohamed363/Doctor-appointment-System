import React from 'react'
import AddNewDoctor from '../Components/AddNewDoctors'
import Header from '../Components/Header'
import Footer from '../Components/Footer'

function AddDoctors1() {
  return (
    <div>

        <Header/>
        <AddNewDoctor/>
        <Footer/>

    </div>
  )
}

export default AddDoctors1