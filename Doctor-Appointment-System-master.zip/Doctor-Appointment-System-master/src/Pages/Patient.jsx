import React from 'react'
import PatientDashboard from '../Components/PatientDashboard'
import PatientMainContainer from '../Components/PatientMainContainer'
import './Patient.css'

function Patient() {
  return (
    <div className='app-body'>
      {/* <PatientDashboard/>
      <PatientMainContainer/> */}
       
    </div>
  )
}

export default Patient