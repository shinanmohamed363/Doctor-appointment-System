import React from 'react'
import UpdateDoctor1 from '../Components/UpdateDoctor1'
import Footer from '../Components/Footer'
import Header from '../Components/Header'
import UpdateDoctorComponent from '../Components/UpdateDoctorComponent'

function UpdateDoctor1page() {
  return (
    <div>
    <Header/>
    <UpdateDoctorComponent/>
    <Footer/>
    </div>
  )
}

export default UpdateDoctor1page