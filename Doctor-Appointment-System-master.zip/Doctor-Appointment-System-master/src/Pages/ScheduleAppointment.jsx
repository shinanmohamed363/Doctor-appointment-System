import React from 'react'
import Footer from '../Components/Footer'
import Header from '../Components/Header'


function ScheduleAppointment() {
  return (
    <div>
        <Header/>
        
        <Footer/>

    </div>
  )
}

export default ScheduleAppointment