import React from 'react'
import Footer from '../Components/Footer'
import Header from '../Components/Header'
import DoctorListForAdmin from '../Components/DoctorListForAdmin'

function DoctorListForAdmin1() {
  return (
    <div>
        <Header/>
        <DoctorListForAdmin/>
        <Footer/>
    </div>
  )
}

export default DoctorListForAdmin1