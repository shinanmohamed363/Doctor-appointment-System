import React from 'react'
import AppointmentHistory from '../Components/AppointmentHistory'
import Footer from '../Components/Footer'
import Header from '../Components/Header'

function HistoryAppointment() {
  return (
    <div>
        <Header/>
        <AppointmentHistory/>
        <Footer/>
        </div>
  )
}

export default HistoryAppointment