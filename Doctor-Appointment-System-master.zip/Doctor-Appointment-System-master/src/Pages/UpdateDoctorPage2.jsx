import React from 'react'
import Footer from '../Components/Footer'
import Header from '../Components/Header'
import UpdateDoctor2 from '../Components/Updatedoctor2'

function UpdateDoctorPage2() {
  return (
    <div>
        <Header/>
        <UpdateDoctor2/>
        <Footer/>
    </div>
  )
}

export default UpdateDoctorPage2