import React from 'react'
import Footer from '../Components/Footer'
import Header from '../Components/Header'
import UpdatePatientProfile from '../Components/UpdateProfile'

function UpdateProfile1() {
  return (
    <div>
        <Header/>
        <UpdatePatientProfile/>
        <Footer/>
    </div>
  )
}

export default UpdateProfile1