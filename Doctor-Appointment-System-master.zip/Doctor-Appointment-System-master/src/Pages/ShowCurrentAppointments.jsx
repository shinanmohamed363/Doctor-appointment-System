import React from 'react'
import Footer from '../Components/Footer'
import Header from '../Components/Header'


function ShowCurrentAppointments() {
  return (
    <div>
        <Header/>
        
        <Footer/>
    </div>
  )
}

export default ShowCurrentAppointments