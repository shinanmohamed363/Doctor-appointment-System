import React from 'react'

function ShowCurrentAppointments() {
  return (
    <div>ShowCurrentAppointments</div>
  )
}

export default ShowCurrentAppointments